import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, RouterStateSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { appState } from '../State/AppState/App.state';

const store = inject(Store<appState>)
export const roleGuardsGuard = (role: string): CanActivateFn => {
   (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
    store.select((state: appState) => state.users.user?.roles?.[0]?.name)
    .subscribe(userRole => {
      return userRole === role;
    })

    
  }
  return store.select;
};
