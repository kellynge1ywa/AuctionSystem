import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';



interface DecodedToken {
  sub: string;
  roles: string[];
  // Other relevant claims
}

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  private localStorageKey='token';
 

  constructor() { }

  getToken():string | null{
    return localStorage.getItem(this.localStorageKey)
  }
  setToken(token:string ):void{
    localStorage.setItem(this.localStorageKey,token);
  }
  isLoggedIn():boolean{
    return !!this.getToken() ?? false;

  }

  logOut():void{
    localStorage.removeItem(this.localStorageKey);

  }

  //Get roles
  getRoles():string[] {
    const token=this.getToken();
    if(!token){
      return [];
    }
    try
    {
      const decodedToken=jwtDecode<DecodedToken>(token);
      return decodedToken.roles
    } catch(error){
      console.error('Error decoding token:',error)
      return [];
    }


  }
  //See if user has role
  hasRole(role:string):boolean{
    const aroles=this.getRoles();
    return aroles && aroles.includes(role);
  }


}
