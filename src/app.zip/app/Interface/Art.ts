export interface Art{
    id:string,
    artName:string,
    price:number,
    startingPrice:number,
    highestBidAmount:number,
    bidStartDate:Date,
    bidEndDate:Date,
    sellerId:string,
    categoryId:string,
    image:string

}
export interface ArtResponse{
    error:string,
    Result:Art[],
    Success:boolean

}

export interface AddArt{
    
}