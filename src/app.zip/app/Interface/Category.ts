export interface Category{
    id:string,
    categoryName:string
}
export interface AddCategory{
    categoryName:string
}

export interface GetCategorySuccess{
    message:string,
}