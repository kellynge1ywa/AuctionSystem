import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { StrongPassword } from '../../Utilities/StrongPassword';
import { AgeValidators } from '../../Utilities/AgeCheck';
import { Store } from '@ngrx/store';

import * as userActions from '../../State/User/Action/Users.actions'
import { appState } from '../../State/AppState/App.state';


@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [ReactiveFormsModule,RouterModule, CommonModule],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent implements OnInit {

  registrationform!: FormGroup;
  constructor (private router:Router,private store:Store<appState>){};

  ngOnInit() {
    this.registrationform= new FormGroup({
      fullname:new FormControl('',[Validators.required, Validators.minLength(5)]),
      email:new FormControl('',[Validators.required, Validators.email]),
      phone:new FormControl('',[Validators.required]),
      dob:new FormControl('', [Validators.required, AgeValidators.dobValidator]),
      password: new FormControl('',[Validators.required, Validators.pattern(StrongPassword)]),
      confirmpassword: new FormControl('',Validators.required)

    },{
      validators:this.passwordMatch
    });
      
  }

  passwordMatch(control:AbstractControl){
    return control.get('password')?.value === control.get('confirmpassword')?.value ? null :
    {mismatch:true};

  }

  get passwordFormField() {
    return this.registrationform.get('password');
  }

  onSubmit(){
    if(this.registrationform.valid){
      try{
        console.log(this.registrationform.value)
        this.store.dispatch(userActions.SignUp({user:this.registrationform.value}))
        this.registrationform.reset()
        this.router.navigate(['/bidder'])
      } catch (error){
        console.error("SignUp failed", error);
      }

        
    }

  }

}
