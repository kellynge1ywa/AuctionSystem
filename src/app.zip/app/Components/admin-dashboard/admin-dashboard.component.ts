import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faRemove, faSignOut } from '@fortawesome/free-solid-svg-icons';
import { ArtService } from '../../Services/art.service';
import { Art } from '../../Interface/Art';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'admin-dashboard',
  standalone: true,
  imports: [CommonModule,RouterModule, FontAwesomeModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit{
  faSignOut=faSignOut
  faRemove= faRemove
  Arts:Art[]=[]
  constructor(private artService:ArtService){}

  ngOnInit() {
    this.getAllArts();   
  }

  getAllArts(){
    this.artService.getAllArts().subscribe(
    Arts =>{
        this.Arts=Arts;
        console.log(this.Arts);
        
      },
      error =>{
        console.log("An error occured",error);
        
      }
    )
  }



}
