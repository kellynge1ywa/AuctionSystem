import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faSignOut } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-view-art',
  standalone: true,
  imports: [FontAwesomeModule, RouterModule],
  templateUrl: './view-art.component.html',
  styleUrl: './view-art.component.css'
})
export class ViewArtComponent {
  faSignOut=faSignOut

}
