import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faSignOut} from '@fortawesome/free-solid-svg-icons';
import { Art, ArtResponse} from '../../Interface/Art';
import { Store } from '@ngrx/store';
import { appState } from '../../State/AppState/App.state';
import * as artActions from '../../State/Art/Action/Art.actions'
import { SelectAllArts } from '../../State/Art/Selector/Art.selectors';
import { CommonModule } from '@angular/common';
import { ArtService } from '../../Services/art.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'bidder',
  standalone: true,
  imports: [CommonModule,RouterModule, FontAwesomeModule],
  templateUrl: './bidder.component.html',
  styleUrl: './bidder.component.css'
})
export class BidderComponent implements OnInit {
  faSignOut=faSignOut
  Arts:Art[]=[]

  constructor(private store:Store<appState>, private router:Router, private artService:ArtService){
    
  }

  ngOnInit() {
    this.getAllArts();   
  }

  getAllArts(){
    this.artService.getAllArts().subscribe(
    Arts =>{
        this.Arts=Arts;
        console.log(this.Arts);
        
      },
      error =>{
        console.log("An error occured",error);
        
      }
    )
  }

}
