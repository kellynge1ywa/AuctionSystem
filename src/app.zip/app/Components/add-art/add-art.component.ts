import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faSignOut } from '@fortawesome/free-solid-svg-icons';
import { Category } from '../../Interface/Category';
import { Store } from '@ngrx/store';
import { appState } from '../../State/AppState/App.state';
import { CategoryService } from '../../Services/category.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-art',
  standalone: true,
  imports: [CommonModule,RouterModule, FontAwesomeModule],
  templateUrl: './add-art.component.html',
  styleUrl: './add-art.component.css'
})
export class AddArtComponent {
  faSignOut=faSignOut

  Category:Category[]=[]

  constructor(private store:Store<appState>, private router:Router, private categoryService:CategoryService){
    
  }

  ngOnInit() {
    this.getAllCategories();   
  }

  getAllCategories(){
    this.categoryService.getAllCategories().subscribe(
    Category =>{
        this.Category=Category;
        console.log(this.Category);
        
      },
      error =>{
        console.log("An error occured",error);
        
      }
    )
  }



}
