import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map, tap } from 'rxjs';
import { Art, ArtResponse } from '../Interface/Art';

@Injectable({
  providedIn: 'root'
})
export class ArtService {
  private allArts= new BehaviorSubject<Art[]>([]);
  arts$:Observable<Art[]>=this.allArts.asObservable();

  constructor(private http:HttpClient) { }

  getAllArts(){
    return this.http.get<{result:Art[]}>('https://localhost:7276/api/Arts').pipe(
      map(res => res.result)
    )
      
      
    }

    getOneArt(Id:string):Observable<Art>{
      return this.http.get<Art>(`https://localhost:7276/api/Arts/${Id}`)
  
    }

  }

  

