import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  message!:string
  token!:string
  UserId!:string

 
}
