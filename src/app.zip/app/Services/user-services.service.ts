import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginSuccess, LoginUser, RegisterUser, RegistrationSuccess } from '../Interface/User';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserServicesService {

  constructor(private http:HttpClient) { }

  SignUpUser(newUser:RegisterUser):Observable<RegistrationSuccess>{
    return this.http.post<RegistrationSuccess>('https://localhost:7151/api/Users/register',newUser);

  }
  SignInUser(User:LoginUser):Observable<LoginSuccess>{
    return this.http.post<LoginSuccess>('https://localhost:7151/api/Users/login',User);
  }
}
